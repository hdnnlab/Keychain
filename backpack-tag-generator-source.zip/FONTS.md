# Embedded fonts

23 Google Fonts families, one static Regular weight each, Latin-subset and
base64-inlined in `src/fonts.js` so the tool works with no network.
**Spicy Rice is the default.** Licences are in `fonts-licenses/` — the OFL
requires the notice travels with the font, so keep that folder if you
redistribute. The subset TTFs are in `fonts-src/`.

Subset charset: ASCII 32–126, plus common accented letters in both cases
(`áéíóúñüàèìòùçâêôäöåøãõšžłćężń` + uppercase), `ß€£¥°•–—’‘“”`.

    pyftsubset FONT.ttf --output-file=out.ttf --text="<charset>" \
      --layout-features= --no-hinting --desubroutinize \
      --drop-tables+=GSUB,GPOS,GDEF,DSIG,LTSH,VDMX,hdmx

2541 KB of TTF becomes 523 KB, which is 699 KB once base64'd.

## Printability

Mean raised-stroke width for "Ollie" on a 50mm tag, measured as 2·area/perimeter
of the extruded lettering. A 0.4mm nozzle wants more than ~0.8mm:

| Font | Stroke |
| --- | --- |
| Playwrite US / CA / HR | 1.53 – 1.56 mm |
| Grand Hotel | 2.22 mm |
| Sarina | 2.32 mm |
| Lily Script One | 2.33 mm |
| Galada, Pacifico, Lobster, Notable | 2.46 mm |
| Oleo Script Swash | 2.60 mm |
| Sancreek, Galindo, Boldonse | 2.68 – 2.91 mm |
| Pirata One, Germania One, Londrina Solid | 3.05 – 3.32 mm |
| Chango, Chicle, Matemasie, Luckiest Guy, **Spicy Rice**, Chewy | 3.41 – 3.72 mm |

All clear the floor. The three Playwrite faces are the thinnest — joined-up
handwriting — so watch them if tag width drops or text raise goes below 2mm.

## Adding a font

Subset it, base64 it, and append `{ id, label, data }` to `src/fonts.js`. Array
order is dropdown order. Users can also upload any TTF/OTF at runtime — parsed
locally with opentype.js, never uploaded anywhere.
