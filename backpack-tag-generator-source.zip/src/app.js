/* ==========================================================================
   Backpack Tag Generator — UI, viewport and export wiring
   ========================================================================== */
import * as THREE from "three";
import { OrbitControls } from "three/examples/jsm/controls/OrbitControls.js";
import * as opentype from "opentype.js";
import { FONTS } from "./fonts.js";
import { buildTag, buildMeshes, toSVG, toSTL, to3MF, statsFor } from "./core.js";

const $ = (id) => document.getElementById(id);
const MM_PER_IN = 25.4;

// Hanger ring geometry is fixed: the sliders are hidden, these are the values
// the solver receives whenever hanger.enabled is true.
const DEFAULT_OUTER_RING_SIZE = 8;    // mm
const DEFAULT_INNER_HOLE_SIZE = 3.5;  // mm
const DEFAULT_HOLE_NUDGE_X = 4.5;     // mm, positive moves the ring right
const DEFAULT_HOLE_NUDGE_Y = -0.5;    // mm, negative moves it down
const TAG_WIDTH_MIN = 50;             // mm
const TAG_WIDTH_MAX = 60;             // mm
const MAX_TAG_HEIGHT = 30;            // mm, a hard cap on the finished tag

// The only colours the tool offers. Order is the order they appear.
const PALETTE = [
  { name: "Purple",    hex: "#8A2BE2" },
  { name: "White",     hex: "#FFFFFF" },
  { name: "Gray",      hex: "#A9A9A9" },
  { name: "Black",     hex: "#000000" },
  { name: "Pink",      hex: "#FF69B4" },
  { name: "Dark Blue", hex: "#00008B" },
  { name: "Red",       hex: "#FF0000" },
  { name: "Red Brown", hex: "#8B3A3A" },
];
const DEFAULT_BACKGROUND_COLOR = "#8A2BE2";   // Purple
const DEFAULT_TEXT_COLOR = "#FFFFFF";         // White
const paletteName = (hex) => {
  const hit = PALETTE.find((c) => c.hex.toLowerCase() === String(hex).toLowerCase());
  return hit ? hit.name : hex;
};

/* ---------------------------------------------------------------- state */
const S = {
  text: "Calla",
  connect: true,
  connectGap: 0,
  fontId: "SpicyRice",
  tagWidth: 55,
  outlinePct: 17,
  // Depth is fixed for now — the inputs exist but are hidden in the markup.
  baseThickness: 4,
  textRaise: 2,
  autoBridge: true,
  // Symbols are temporarily removed from the UI; the solver still accepts them,
  // so restoring the picker only means re-adding the controls.
  symbol: { id: "star", position: "none", sizePct: 70, offsetX: 0, offsetY: 0 },
  hanger: {
    enabled: true,
    position: "top-left",
    outerD: DEFAULT_OUTER_RING_SIZE,
    innerD: DEFAULT_INNER_HOLE_SIZE,
    offsetX: DEFAULT_HOLE_NUDGE_X,
    offsetY: DEFAULT_HOLE_NUDGE_Y,
  },
  baseColor: DEFAULT_BACKGROUND_COLOR,
  textColor: DEFAULT_TEXT_COLOR,
  view: "3d",
  cutView: false,
};

const fontCache = new Map();
let customFont = null;
let tag = null;
let modelGroup = null;

/* ------------------------------------------------------------ font loading */
const B64 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
const B64LOOKUP = (() => {
  const t = new Uint8Array(256).fill(255);
  for (let i = 0; i < B64.length; i++) t[B64.charCodeAt(i)] = i;
  return t;
})();

/** Self-contained base64 -> ArrayBuffer; avoids relying on a host atob. */
function b64ToBuffer(b64) {
  let len = b64.length;
  while (len > 0 && b64.charCodeAt(len - 1) === 61) len--;      // trim '='
  const bytes = new Uint8Array((len * 3) >> 2);
  let acc = 0, bits = 0, out = 0;
  for (let i = 0; i < len; i++) {
    const v = B64LOOKUP[b64.charCodeAt(i)];
    if (v === 255) continue;
    acc = (acc << 6) | v;
    bits += 6;
    if (bits >= 8) {
      bits -= 8;
      bytes[out++] = (acc >> bits) & 0xff;
    }
  }
  return bytes.buffer.slice(0, out);
}

function getFont() {
  if (S.fontId === "__custom" && customFont) return customFont;
  if (fontCache.has(S.fontId)) return fontCache.get(S.fontId);
  const entry = FONTS.find((f) => f.id === S.fontId) || FONTS[0];
  const font = opentype.parse(b64ToBuffer(entry.data));
  fontCache.set(entry.id, font);
  return font;
}

/* --------------------------------------------------------------- helpers */
const MOBILE = () => window.matchMedia("(max-width: 1023px)").matches;
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));

const fmt = (mm) => (Math.round(mm * 10) / 10).toFixed(1);

/** Paint the filled portion of every slider track. */
function paintRange(el) {
  const min = +el.min || 0, max = +el.max || 100;
  const pct = max === min ? 0 : ((+el.value - min) / (max - min)) * 100;
  el.style.setProperty("--pct", pct.toFixed(2) + "%");
}
function paintAllRanges() {
  document.querySelectorAll('input[type="range"]').forEach(paintRange);
}

/* ------------------------------------------------------------ 3D viewport */
const V = { ok: false, viewDir: new THREE.Vector3(0, 1, 0.0002), zoom: 1, lastW: 0, lastH: 0 };
function initViewport() {
  const mount = $("viewport");
  V.scene = new THREE.Scene();
  V.scene.background = new THREE.Color("#070b12");

  V.camera = new THREE.PerspectiveCamera(40, 1, 0.5, 4000);
  V.camera.position.set(0, 120, 0.2);

  V.renderer = new THREE.WebGLRenderer({ antialias: true });
  V.renderer.setPixelRatio(Math.min(devicePixelRatio || 1, 2));
  V.renderer.shadowMap.enabled = true;
  V.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  V.renderer.outputEncoding = THREE.sRGBEncoding;
  mount.appendChild(V.renderer.domElement);
  V.renderer.domElement.style.display = "block";
  V.renderer.domElement.style.touchAction = "none";   // rotate/pinch instead of page scroll

  V.controls = new OrbitControls(V.camera, V.renderer.domElement);
  V.controls.enableDamping = true;
  V.controls.dampingFactor = 0.09;
  V.controls.enablePan = false;      // panning on a phone just loses the model
  V.controls.target.set(0, 0, 0);
  V.controls.minDistance = 8;
  V.controls.maxDistance = 900;

  V.scene.add(new THREE.HemisphereLight(0xcfe0ff, 0x0a0f18, 0.9));
  const key = new THREE.DirectionalLight(0xffffff, 1.45);
  key.position.set(-70, 120, 80);
  key.castShadow = true;
  key.shadow.mapSize.set(2048, 2048);
  key.shadow.camera.near = 5;
  key.shadow.camera.far = 500;
  key.shadow.bias = -0.0012;
  V.key = key;
  V.scene.add(key);
  const fill = new THREE.DirectionalLight(0x9dc4ff, 0.5);
  fill.position.set(90, 50, -90);
  V.scene.add(fill);

  const floor = new THREE.Mesh(
    new THREE.PlaneGeometry(2000, 2000),
    new THREE.MeshStandardMaterial({ color: 0x0c121c, roughness: 1 })
  );
  floor.rotation.x = -Math.PI / 2;
  floor.position.y = 0;
  floor.receiveShadow = true;
  V.scene.add(floor);

  const grid = new THREE.GridHelper(600, 60, 0x24364d, 0x141d29);
  V.scene.add(grid);
  V.floor = floor;
  V.grid = grid;

  V.wrapper = new THREE.Group();
  V.wrapper.rotation.x = -Math.PI / 2;      // model is Z-up, bed is Y-up
  V.scene.add(V.wrapper);

  /**
   * setSize's third argument must stay true. With updateStyle=false the drawing
   * buffer becomes w*dpr x h*dpr while no CSS size is written, so on a 2x phone
   * the canvas lays out at twice its container and the render spills off the
   * bottom-right. Re-fit afterwards so a rotation can't leave the tag clipped.
   */
  const resize = () => {
    const w = mount.clientWidth || 1, h = mount.clientHeight || 1;
    if (w === V.lastW && h === V.lastH) return;
    V.lastW = w; V.lastH = h;
    V.renderer.setSize(w, h, true);
    V.camera.aspect = w / h;
    V.camera.updateProjectionMatrix();
    applyView();
  };
  V.ok = true;              // set before the first resize so it can fit immediately
  resize();
  new ResizeObserver(resize).observe(mount);

  // A lost GPU context leaves a blank canvas with no error in the console.
  V.renderer.domElement.addEventListener("webglcontextlost", (e) => {
    e.preventDefault();
    V.ok = false;
    showNote("The 3D view lost its graphics context. Switch to 2D, or reload the page.", "err", 0);
  });
  V.renderer.domElement.addEventListener("webglcontextrestored", () => {
    V.ok = true;
    V.lastW = V.lastH = 0;
    resize();
  });
  window.addEventListener("orientationchange", () => setTimeout(resize, 350));

  // Remember how the user framed things so a resize preserves their angle+zoom.
  V.controls.addEventListener("end", () => {
    const off = V.camera.position.clone().sub(V.controls.target);
    if (off.lengthSq() < 1e-6) return;
    V.viewDir.copy(off).normalize();
    const fit = fitDistance(V.viewDir);
    if (fit > 0) V.zoom = clamp(off.length() / fit, 0.25, 4);
  });

  (function loop() {
    requestAnimationFrame(loop);
    V.controls.update();
    V.renderer.render(V.scene, V.camera);
  })();
}

/** No WebGL (old browser, blocked GPU) shouldn't kill the tool — fall back to 2D. */
function viewportUnavailable() {
  $("viewport").innerHTML =
    '<div class="flex h-full items-center justify-center p-6 text-center text-xs text-slate-500">' +
    "This browser can't open a 3D view, so the 2D preview is showing instead. " +
    "Exports still work." + "</div>";
}

const VIEW_DIRS = {
  top:   new THREE.Vector3(0, 1, 0.0002),   // epsilon keeps `up` from degenerating
  iso:   new THREE.Vector3(0.62, 0.72, 0.86),
  front: new THREE.Vector3(0, 0.08, 1),
};
const FIT_MARGIN = 1.08;

/**
 * Exact distance at which every corner of `box` falls inside BOTH the vertical
 * and the horizontal frustum, for a camera at dir*d looking at the origin.
 * A bounding-sphere fit would also guarantee a fit, but it over-zooms badly for
 * a wide flat tag on a short, wide mobile canvas.
 *
 * Pure and exported so it can be verified against a real frustum in tests.
 * `box` is expected to be centred on the origin (the model is).
 */
export function fitDistanceForBox(box, dir, fovDeg, aspect, margin = FIT_MARGIN) {
  if (!box || box.isEmpty() || !(aspect > 0)) return 0;

  const u = dir.clone().normalize();
  const ref = Math.abs(u.y) > 0.999 ? new THREE.Vector3(0, 0, 1) : new THREE.Vector3(0, 1, 0);
  const right = new THREE.Vector3().crossVectors(ref, u).normalize();
  const camUp = new THREE.Vector3().crossVectors(u, right).normalize();

  const vTan = Math.tan(THREE.MathUtils.degToRad(fovDeg) / 2);
  const hTan = vTan * aspect;

  let dist = 0;
  const c = new THREE.Vector3();
  for (let i = 0; i < 8; i++) {
    c.set(i & 1 ? box.max.x : box.min.x,
          i & 2 ? box.max.y : box.min.y,
          i & 4 ? box.max.z : box.min.z);
    const depth = c.dot(u);                       // component toward the camera
    dist = Math.max(dist,
      depth + Math.abs(c.dot(right)) / hTan,
      depth + Math.abs(c.dot(camUp)) / vTan);
  }
  return dist * margin;
}

function fitDistance(dir) {
  const box = new THREE.Box3().setFromObject(V.wrapper);
  return box.isEmpty() ? 0 : fitDistanceForBox(box, dir, V.camera.fov, V.camera.aspect);
}

/** Point the camera at the origin from V.viewDir at the fitted distance. */
function applyView() {
  if (!V.ok || !modelGroup) return;
  const dist = fitDistance(V.viewDir);
  if (!(dist > 0)) return;
  V.controls.target.set(0, 0, 0);                 // model is centred on the origin
  V.camera.position.copy(V.viewDir).normalize().multiplyScalar(dist * V.zoom);
  V.camera.lookAt(0, 0, 0);
  V.camera.updateProjectionMatrix();
  V.controls.update();
}

/** Toolbar presets — snap back to a known angle and reset the user's zoom. */
function frameModel(angle) {
  const preset = VIEW_DIRS[angle] || VIEW_DIRS.iso;
  V.viewDir.copy(preset).normalize();
  V.zoom = 1;
  applyView();
}

/* ------------------------------------------------------------- 2D preview */
function render2D() {
  if (!tag) return;
  const svg = toSVG(tag, {
    mode: S.cutView ? "cut" : "preview",
    baseColor: S.baseColor,
    textColor: S.textColor,
  })
    .replace(/width="[\d.]+mm" height="[\d.]+mm"/, 'width="100%" height="100%"')
    .replace("<svg ", '<svg style="max-width:100%;max-height:100%" ');
  $("svgview").innerHTML = svg;
}

/* ------------------------------------------------------------- the rebuild */
let timer = null;
function scheduleRebuild() {
  clearTimeout(timer);
  $("busy").classList.remove("hidden");
  $("busy").classList.add("flex");
  timer = setTimeout(() => requestAnimationFrame(rebuild), 130);
}

function rebuild() {
  const warn = [];
  if (!S.text.trim()) warn.push("Type some text to generate a tag.");
  if (S.hanger.enabled && S.hanger.innerD >= S.hanger.outerD - 1) {
    warn.push("Inner hole must be at least 1mm smaller than the outer ring.");
  }

  try {
    tag = buildTag({
      text: S.text,
      font: getFont(),
      connect: S.connect,
      connectGap: S.connectGap,
      tagWidth: S.tagWidth,
      maxHeight: MAX_TAG_HEIGHT,
      outlinePct: S.outlinePct,
      autoBridge: S.autoBridge,
      symbol: S.symbol,
      hanger: {
        ...S.hanger,
        innerD: Math.min(S.hanger.innerD, S.hanger.outerD - 1),
      },
    });
  } catch (err) {
    console.error("tag solve failed:", err);
    tag = null;
    warn.push("Could not solve that shape — try different settings.");
  }

  if (tag) {
    if (modelGroup) {
      if (V.wrapper) V.wrapper.remove(modelGroup);
      modelGroup.traverse((o) => {
        if (o.geometry) o.geometry.dispose();
        if (o.material) o.material.dispose();
      });
    }
    modelGroup = buildMeshes(tag, {
      baseThickness: S.baseThickness,
      textRaise: S.textRaise,
      baseColor: S.baseColor,
      textColor: S.textColor,
    });
    if (V.ok) {
      V.wrapper.add(modelGroup);
      const span = Math.max(tag.dims.width, tag.dims.height, 40);
      V.key.shadow.camera.left = -span; V.key.shadow.camera.right = span;
      V.key.shadow.camera.top = span; V.key.shadow.camera.bottom = -span;
      V.key.shadow.camera.updateProjectionMatrix();

      // The model is centred on the origin now, so the bed sits below it.
      const under = new THREE.Box3().setFromObject(V.wrapper).min.y;
      V.floor.position.y = under - 0.06;
      V.grid.position.y = under - 0.04;

      if (!V.framed) {
        frameModel(MOBILE() ? "top" : "iso");
        V.framed = true;
      } else {
        applyView();          // geometry changed: re-fit, keep the user's angle
      }
    }

    const st = statsFor(tag);
    $("s-ow").textContent = fmt(tag.dims.width);
    const capped = tag.dims.width < S.tagWidth - 0.2;
    $("ct-cap").textContent = capped ? `capped to ${fmt(MAX_TAG_HEIGHT)} mm tall` : "";
    $("ct-cap").classList.toggle("hidden", !capped);
    $("s-oh").textContent = fmt(tag.dims.height);
    $("s-z").textContent = fmt(S.baseThickness + S.textRaise);
    $("s-pieces").textContent = st.pieces + " / " + st.holes;
    if (st.pieces > 1) warn.push(`Tag is in ${st.pieces} separate pieces — turn on "Keep tag in one piece" or raise the outline size.`);
    if (S.baseThickness < 1.2) warn.push("Base under 1.2mm is fragile for a printed tag.");
    render2D();
  }

  // Persistent (ms = 0) so a real problem stays on screen; export notes fade.
  if (warn.length) showNote(warn[0], "info", 0);
  else hideNote();
  $("busy").classList.add("hidden");
  $("busy").classList.remove("flex");
}

/* ---------------------------------------------------------------- exports */
const IS_IOS = /iPad|iPhone|iPod/.test(navigator.userAgent) ||
  (navigator.platform === "MacIntel" && navigator.maxTouchPoints > 1);

/** Transient message in the preview's warning strip. */
let noteTimer = null;
function showNote(msg, tone = "info", ms = 4500) {
  const box = $("warn");
  box.textContent = msg;
  box.classList.remove("hidden", "border-amber-600/60", "bg-amber-950/95", "text-amber-200",
                       "border-lime-500/60", "bg-lime-950/95", "text-lime-200",
                       "border-rose-600/60", "bg-rose-950/95", "text-rose-200");
  const tones = {
    info: ["border-amber-600/60", "bg-amber-950/95", "text-amber-200"],
    ok:   ["border-lime-500/60", "bg-lime-950/95", "text-lime-200"],
    err:  ["border-rose-600/60", "bg-rose-950/95", "text-rose-200"],
  };
  box.classList.add("flex", ...(tones[tone] || tones.info));
  clearTimeout(noteTimer);
  if (ms) noteTimer = setTimeout(hideNote, ms);
}

function hideNote() {
  clearTimeout(noteTimer);
  const box = $("warn");
  box.classList.add("hidden");
  box.classList.remove("flex");
}

/**
 * Saving a file from a phone has three traps this works around:
 *  - iOS Safari's `<a download>` is unreliable, especially from a file:// page
 *    or an in-app browser, so try the Web Share sheet first there.
 *  - Removing the anchor in the same tick cancels the download on several
 *    mobile browsers; the element and its object URL have to outlive the click.
 *  - A specific MIME like model/stl makes some browsers navigate to a preview
 *    instead of saving, so everything goes out as a generic binary stream.
 * Both paths need the user's tap still to be "live", so callers must not await
 * anything slow before getting here.
 */
async function saveFile(data, name) {
  const blob = data instanceof Blob ? data : new Blob([data], { type: "application/octet-stream" });

  if (IS_IOS && typeof File === "function" && navigator.canShare) {
    try {
      const file = new File([blob], name, { type: "application/octet-stream" });
      if (navigator.canShare({ files: [file] })) {
        await navigator.share({ files: [file], title: name });
        return "shared";
      }
    } catch (err) {
      if (err && err.name === "AbortError") return "cancelled";
      // otherwise fall through to the anchor
    }
  }

  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = name;
  a.rel = "noopener";
  a.style.display = "none";
  document.body.appendChild(a);

  if (typeof a.download === "undefined") {   // very old browsers: no download attr
    window.open(url, "_blank");
  } else {
    a.click();
  }
  setTimeout(() => { a.remove(); URL.revokeObjectURL(url); }, 60000);
  return "downloaded";
}

/** Run an export with feedback, so a failure is never silent. */
async function runExport(btn, label, build) {
  if (!tag || !modelGroup) {
    showNote("Nothing to export yet — type a name first.", "err");
    return;
  }
  const original = btn.innerHTML;
  btn.disabled = true;
  btn.style.opacity = "0.65";
  try {
    const { data, filename } = build();          // synchronous: keeps the tap live
    const how = await saveFile(data, filename);
    if (how === "cancelled") showNote("Export cancelled.", "info", 2500);
    else if (how === "shared") showNote(`${label} ready — choose where to save it.`, "ok");
    else showNote(`${filename} saved to your downloads.`, "ok");
  } catch (err) {
    showNote(`${label} failed: ${err && err.message ? err.message : "unknown error"}`, "err", 8000);
  } finally {
    btn.disabled = false;
    btn.style.opacity = "";
    btn.innerHTML = original;
  }
}

const safeName = () =>
  (S.text.trim().replace(/[^A-Za-z0-9]+/g, "-").replace(/^-|-$/g, "") || "tag").slice(0, 40);

/* -------------------------------------------------------------- UI wiring */
/**
 * On phones, touching a slider while a text input still holds focus leaves the
 * soft keyboard up (and on some browsers re-opens it), which covers half the
 * controls. Drop focus the moment a non-text control is touched, and never let
 * a range keep focus after the gesture ends.
 */
function suppressKeyboard() {
  const isTextEntry = (el) =>
    el && (el.tagName === "INPUT" || el.tagName === "TEXTAREA" || el.tagName === "SELECT") &&
    !["range", "checkbox", "color", "file", "button"].includes(el.type);

  document.addEventListener("pointerdown", (e) => {
    const t = e.target;
    const tappingText = isTextEntry(t);
    if (!tappingText && isTextEntry(document.activeElement)) document.activeElement.blur();
    // A range never needs focus from a pointer — only from the keyboard.
    if (t && t.type === "range") {
      const release = () => {
        t.blur();
        window.removeEventListener("pointerup", release);
        window.removeEventListener("pointercancel", release);
      };
      window.addEventListener("pointerup", release);
      window.addEventListener("pointercancel", release);
    }
  }, true);

  // Enter/Go on the name field should dismiss the keyboard, not submit anything.
  $("f-text").addEventListener("keydown", (e) => { if (e.key === "Enter") e.target.blur(); });
}

function bind() {
  suppressKeyboard();

  // keep every slider's filled track in sync
  document.addEventListener("input", (e) => {
    if (e.target && e.target.type === "range") paintRange(e.target);
  }, true);

  // text
  $("f-text").addEventListener("input", (e) => {
    S.text = e.target.value;
    $("ct-count").textContent = S.text.length;
    scheduleRebuild();
  });
  $("f-connect").addEventListener("change", (e) => {
    S.connect = e.target.checked;
    $("wrap-gap").style.display = S.connect ? "" : "none";
    scheduleRebuild();
  });
  $("f-gap").addEventListener("input", (e) => {
    S.connectGap = +e.target.value;
    $("ct-gap").textContent = S.connectGap + "%";
    scheduleRebuild();
  });

  // fonts
  const sel = $("f-font");
  FONTS.forEach((f) => sel.add(new Option(f.label, f.id)));
  sel.value = S.fontId;
  sel.addEventListener("change", (e) => { S.fontId = e.target.value; scheduleRebuild(); });

  $("f-fontfile").addEventListener("change", async (e) => {
    const file = e.target.files && e.target.files[0];
    e.target.value = "";
    if (!file) return;
    try {
      customFont = opentype.parse(await file.arrayBuffer());
      if (!sel.querySelector('option[value="__custom"]')) sel.add(new Option("Uploaded font", "__custom"));
      sel.querySelector('option[value="__custom"]').textContent = file.name;
      sel.value = "__custom";
      S.fontId = "__custom";
      scheduleRebuild();
    } catch {
      showNote("That font could not be read. Try a .ttf or .otf.", "err", 6000);
    }
  });
  $("f-fontclear").addEventListener("click", () => {
    customFont = null;
    const opt = sel.querySelector('option[value="__custom"]');
    if (opt) opt.remove();
    sel.value = S.fontId = FONTS[0].id;
    scheduleRebuild();
  });

  // dimensions
  $("f-width").addEventListener("input", (e) => {
    S.tagWidth = clamp(+e.target.value, TAG_WIDTH_MIN, TAG_WIDTH_MAX);
    $("ct-w").textContent = fmt(S.tagWidth) + " mm";
    scheduleRebuild();
  });
  $("f-outline").addEventListener("input", (e) => {
    S.outlinePct = +e.target.value;
    $("ct-out").textContent = S.outlinePct + "%";
    scheduleRebuild();
  });
  $("f-base").addEventListener("input", (e) => { S.baseThickness = +e.target.value || 0.4; scheduleRebuild(); });
  $("f-raise").addEventListener("input", (e) => { S.textRaise = +e.target.value || 0.2; scheduleRebuild(); });
  $("f-bridge").addEventListener("change", (e) => { S.autoBridge = e.target.checked; scheduleRebuild(); });

  // hanger
  $("f-hang").addEventListener("change", (e) => { S.hanger.enabled = e.target.checked; scheduleRebuild(); });
  $("f-hangpos").addEventListener("click", (e) => {
    const b = e.target.closest("[data-hp]");
    if (!b) return;
    S.hanger.position = b.dataset.hp;
    $("f-hangpos").querySelectorAll("[data-hp]").forEach((x) => x.classList.toggle("chip-on", x === b));
    scheduleRebuild();
  });
  $("f-outer").addEventListener("input", (e) => {
    S.hanger.outerD = +e.target.value;
    $("ct-outer").textContent = fmt(S.hanger.outerD) + " mm";
    scheduleRebuild();
  });
  $("f-inner").addEventListener("input", (e) => {
    S.hanger.innerD = +e.target.value;
    $("ct-inner").textContent = fmt(S.hanger.innerD) + " mm";
    scheduleRebuild();
  });
  $("f-holex").addEventListener("input", (e) => {
    S.hanger.offsetX = +e.target.value;
    $("ct-hx").textContent = S.hanger.offsetX;
    scheduleRebuild();
  });
  $("f-holey").addEventListener("input", (e) => {
    S.hanger.offsetY = +e.target.value;
    $("ct-hy").textContent = S.hanger.offsetY;
    scheduleRebuild();
  });

  // colours — fixed palette, no freeform picker
  buildSwatches("sw-bg", "ct-bg", () => S.baseColor, (hex) => {
    S.baseColor = hex;
    if (modelGroup) modelGroup.getObjectByName("base").material.color.set(hex);
    render2D();
  });
  buildSwatches("sw-fg", "ct-fg", () => S.textColor, (hex) => {
    S.textColor = hex;
    if (modelGroup) modelGroup.getObjectByName("text").material.color.set(hex);
    render2D();
  });

  // view switching
  const setView = (v) => {
    S.view = v;
    const is3d = v === "3d";
    $("viewport").classList.toggle("hidden", !is3d);
    $("svgview").classList.toggle("hidden", is3d);
    $("svgview").classList.toggle("flex", !is3d);
    $("v3d-tools").classList.toggle("hidden", !is3d);
    $("v2d-tools").classList.toggle("hidden", is3d);
    $("v2d-tools").classList.toggle("flex", !is3d);
    $("v-3d").className = "px-3 py-1.5 text-[11px] font-semibold " + (is3d ? "bg-lime-400 text-slate-950" : "text-slate-400 hover:text-slate-200");
    $("v-2d").className = "px-3 py-1.5 text-[11px] font-semibold " + (is3d ? "text-slate-400 hover:text-slate-200" : "bg-lime-400 text-slate-950");
    if (!is3d) render2D();
  };
  $("v-3d").addEventListener("click", () => setView("3d"));
  $("v-2d").addEventListener("click", () => setView("2d"));
  setView("3d");

  $("v3d-tools").addEventListener("click", (e) => {
    const b = e.target.closest("[data-view]");
    if (b) frameModel(b.dataset.view === "fit" ? "iso" : b.dataset.view);
  });
  $("f-cutview").addEventListener("change", (e) => { S.cutView = e.target.checked; render2D(); });

  // accordions
  document.querySelectorAll("[data-acc]").forEach((btn) => {
    btn.addEventListener("click", () => {
      const body = document.querySelector(`[data-body="${btn.dataset.acc}"]`);
      const open = body.style.display !== "none";
      body.style.display = open ? "none" : "";
      btn.querySelector("[data-acc-m]").textContent = open ? "+" : "−";
    });
  });

  // exports
  $("btn-svg").addEventListener("click", (e) =>
    runExport(e.currentTarget, "SVG", () => ({
      data: toSVG(tag, { mode: "cut", baseColor: S.baseColor, textColor: S.textColor }),
      filename: safeName() + "-tag.svg",
    })));

  $("btn-stl").addEventListener("click", (e) =>
    runExport(e.currentTarget, "STL", () => ({
      data: toSTL(modelGroup),
      filename: safeName() + "-tag.stl",
    })));

  // 3MF zips asynchronously, which spends the tap's transient activation. Build
  // it first, then hand the finished blob over on the next tap if the browser
  // refuses the automatic save.
  $("btn-3mf").addEventListener("click", async (e) => {
    const btn = e.currentTarget;
    if (!modelGroup) { showNote("Nothing to export yet — type a name first.", "err"); return; }
    btn.disabled = true;
    btn.style.opacity = "0.65";
    try {
      const blob = await to3MF(modelGroup, { baseColor: S.baseColor, textColor: S.textColor, title: safeName() });
      const how = await saveFile(blob, safeName() + "-tag.3mf");
      if (how === "cancelled") showNote("Export cancelled.", "info", 2500);
      else showNote("3MF ready.", "ok");
    } catch (err) {
      showNote("3MF failed: " + (err && err.message ? err.message : "unknown error"), "err", 8000);
    } finally {
      btn.disabled = false;
      btn.style.opacity = "";
    }
  });
}

/**
 * A row of preset colour buttons. Only one can be active; the active one gets a
 * ring, and white/black need their own outline to stay visible against the panel.
 */
function buildSwatches(containerId, labelId, getCurrent, onPick) {
  const host = $(containerId);
  const label = $(labelId);
  host.innerHTML = "";

  const paint = () => {
    const current = String(getCurrent()).toLowerCase();
    host.querySelectorAll("[data-hex]").forEach((b) => {
      const on = b.dataset.hex.toLowerCase() === current;
      b.setAttribute("aria-checked", on ? "true" : "false");
      b.className =
        "h-9 w-full rounded-lg border transition active:scale-95 " +
        (on
          ? "border-transparent ring-2 ring-lime-400 ring-offset-2 ring-offset-slate-950"
          : "border-slate-600/70 sm:hover:border-slate-400");
    });
    if (label) label.textContent = paletteName(getCurrent());
  };

  PALETTE.forEach((c) => {
    const b = document.createElement("button");
    b.type = "button";
    b.dataset.hex = c.hex;
    b.style.backgroundColor = c.hex;
    b.title = `${c.name} ${c.hex}`;
    b.setAttribute("role", "radio");
    b.setAttribute("aria-label", c.name);
    b.addEventListener("click", () => { onPick(c.hex); paint(); });
    host.appendChild(b);
  });
  paint();
}

/* ------------------------------------------------------------------- boot */
try {
  initViewport();
} catch (err) {
  viewportUnavailable();
}
bind();
paintAllRanges();
if (!V.ok) $("v-2d").click();
rebuild();
frameModel(MOBILE() ? "top" : "iso");

// The ResizeObserver already re-fits on every container change. This only
// resets the preset angle when the layout crosses the desktop breakpoint.
let wasMobile = MOBILE();
let breakpointTimer = null;
window.addEventListener("resize", () => {
  clearTimeout(breakpointTimer);
  breakpointTimer = setTimeout(() => {
    const nowMobile = MOBILE();
    if (nowMobile !== wasMobile) {
      wasMobile = nowMobile;
      frameModel(nowMobile ? "top" : "iso");
    }
  }, 250);
});
