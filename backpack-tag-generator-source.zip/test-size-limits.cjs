const core=require('./core.cjs'), op=require('opentype.js'), fs=require('fs');
const cache={}; const load=n=>cache[n]||(cache[n]=(()=>{const b=fs.readFileSync('fonts-src/'+n+'.ttf');return op.parse(b.buffer.slice(b.byteOffset,b.byteOffset+b.length));})());
const fonts=fs.readdirSync('sub2').filter(f=>f.endsWith('.ttf')).map(f=>f.replace('.ttf',''));
let cases=0, over=[], pieces=[], worst=0, narrowest=99;
for (const f of fonts)
for (const txt of ['Jo','Calla','Ollie','Sam & Ivy','Christopher B'])
for (const wmm of [50,55,60])
for (const pos of ['top-left','top']) {
  const t=core.buildTag({text:txt,font:load(f),connect:false,connectGap:0,tagWidth:wmm,outlinePct:17,
    autoBridge:true,maxHeight:30,
    symbol:{id:'star',position:'none',sizePct:70,offsetX:0,offsetY:0},
    hanger:{enabled:true,position:pos,outerD:8,innerD:3.5,offsetX:4.5,offsetY:-0.5}});
  cases++;
  if(!t){ over.push(f+'/'+txt+' null'); continue; }
  worst=Math.max(worst,t.dims.height);
  narrowest=Math.min(narrowest,t.dims.width);
  if(t.dims.height>30.05) over.push(f+'/'+txt+'/'+wmm+'/'+pos+' H='+t.dims.height.toFixed(2));
  if(core.statsFor(t).pieces>1) pieces.push(f+'/'+txt+'/'+wmm+'/'+pos);
  if(core.statsFor(t).holes<1) pieces.push(f+'/'+txt+' NO HOLE');
}
console.log(cases+' combinations with maxHeight 30');
console.log('  tallest result: '+worst.toFixed(2)+' mm  | over cap: '+(over.length?over.slice(0,5).join(', '):'none'));
console.log('  multi-piece / missing hole: '+(pieces.length?pieces.slice(0,5).join(', '):'none'));
console.log('  narrowest result (height-limited): '+narrowest.toFixed(1)+' mm');
