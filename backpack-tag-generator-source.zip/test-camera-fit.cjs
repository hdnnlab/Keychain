// Verify the camera fit against a real THREE frustum.
const { JSDOM } = require('jsdom'); const fs = require('fs');
const dom = new JSDOM(fs.readFileSync('index.html','utf8').replace(/<script[\s\S]*?<\/script>/g,''), { pretendToBeVisual:true, url:'http://localhost/' });
const w = dom.window;
['window','document','navigator','HTMLElement','Option','Blob','FileReader','requestAnimationFrame','Image','Event'].forEach(k=>{ if(w[k]!==undefined) global[k]=w[k]; });
global.ResizeObserver = class { observe(){} disconnect(){} };
global.requestAnimationFrame = fn => setTimeout(fn,0);
w.matchMedia = q => ({ matches:/max-width:\s*1023px/.test(q), addEventListener(){}, removeEventListener(){}, addListener(){}, removeListener(){} });
global.matchMedia = w.matchMedia; global.self = global.window = w;
global.URL.createObjectURL=()=>'blob:x'; global.URL.revokeObjectURL=()=>{};
global.PointerEvent = w.PointerEvent || w.Event;

const app = require('./apptest.cjs');
const THREE = require('three');
const fit = app.fitDistanceForBox;

// realistic tags (w x h x z, mm) and realistic canvas aspects
const tags = [[54.4,20.5,6],[76.6,24.6,6],[50,9.5,6],[70,47.5,6],[58,31,6]];
const aspects = { 'phone portrait preview (375x170)':375/170, 'phone landscape (740x230)':740/230,
                  'tablet (820x520)':820/520, 'desktop (900x700)':900/700, 'narrow (320x480)':320/480 };
const dirs = { top:new THREE.Vector3(0,1,0.0002), iso:new THREE.Vector3(0.62,0.72,0.86), front:new THREE.Vector3(0,0.08,1) };

let worstSlack = 0, fails = 0, tooLoose = 0, checks = 0;
for (const [tw,th,tz] of tags) {
  // model is centred on the origin, then tilted like the viewport does
  const box = new THREE.Box3(new THREE.Vector3(-tw/2,-tz/2,-th/2), new THREE.Vector3(tw/2,tz/2,th/2));
  for (const [label,aspect] of Object.entries(aspects)) {
    for (const [dn,dir] of Object.entries(dirs)) {
      const d = fit(box, dir, 42, aspect);
      const cam = new THREE.PerspectiveCamera(42, aspect, 0.5, 4000);
      cam.position.copy(dir).normalize().multiplyScalar(d);
      cam.lookAt(0,0,0); cam.updateMatrixWorld(true); cam.updateProjectionMatrix();

      // project all 8 corners into NDC
      let maxNdc = 0;
      for (let i=0;i<8;i++){
        const c = new THREE.Vector3(i&1?box.max.x:box.min.x, i&2?box.max.y:box.min.y, i&4?box.max.z:box.min.z);
        const n = c.clone().project(cam);
        maxNdc = Math.max(maxNdc, Math.abs(n.x), Math.abs(n.y));
      }
      checks++;
      if (maxNdc > 1.0) { fails++; console.log('  CLIPPED', tw+'x'+th, label, dn, 'ndc', maxNdc.toFixed(3)); }
      if (maxNdc < 0.60) { tooLoose++; console.log('  loose  ', tw+'x'+th, label, dn, 'fills only', (maxNdc*100).toFixed(0)+'%'); }
      worstSlack = Math.max(worstSlack, maxNdc);
    }
  }
}
console.log(checks+' fit checks | clipped: '+fails+' | wasteful: '+tooLoose);
console.log('tightest fill reaches '+(worstSlack*100).toFixed(1)+'% of the frame edge (1.0 = touching)');

// the fit must react to aspect: a narrower canvas needs the camera further back
const box = new THREE.Box3(new THREE.Vector3(-27,-3,-10), new THREE.Vector3(27,3,10));
const wide = fit(box, dirs.top, 42, 2.2), narrow = fit(box, dirs.top, 42, 0.66);
console.log('same tag, top view: wide canvas d=%s | narrow canvas d=%s | pulls back: %s',
  wide.toFixed(1), narrow.toFixed(1), narrow > wide);
