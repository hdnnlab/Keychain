# Backpack Tag Generator

Type a name, get a laser-ready SVG, a printable STL, or a two-material 3MF.

    npm install
    npm run build          # writes app.css + app.js next to index.html
    npm run test:camera    # verifies the camera fit against a real frustum

## Layout

| File | What it does |
| --- | --- |
| `src/core.js` | All geometry. opentype outlines → flatten → Clipper union/offset/boolean → THREE meshes → SVG / STL / 3MF. No DOM access. |
| `src/app.js` | Controls, viewport, camera fit, export wiring. |
| `src/fonts.js` | 23 Google Fonts families, subset and inlined. See `FONTS.md`. |
| `tw.css` | Base layer (slider skin, preview and canvas sizing) plus component classes. |
| `fonts-licenses/` | OFL / Apache notices. Keep on redistribution. |

## Defaults

Text "Calla", font Spicy Rice, weld gap 0%, outline 17%, tag width 50mm, base
depth 4mm, text raise 2mm, hanger top-left with an 8mm ring, a 3.5mm hole
(2.25mm wall) and a nudge of (+4.5, −0.5) mm.

That nudge tucks the ring inside the plate's footprint rather than letting it
overhang the left edge, so the finished tag measures exactly the requested width
— "Calla" comes out 50.0 × 25.6 mm instead of 54.4 × 26.1 mm.

Weld gap 0 means the "Connect text" toggle is a no-op until the gap is raised —
`weld()` returns its input unchanged at zero. Raising it runs a morphological
closing that bridges nearly-touching letters.

## Fixed values (controls hidden, solver still fed)

The input stays in the DOM inside a `hidden` wrapper so existing handlers and the
solver keep reading it. Remove the wrapper to expose the control — no JS change.

| Parameter | Value | Constant |
| --- | --- | --- |
| Outer ring | 8 mm | `DEFAULT_OUTER_RING_SIZE` |
| Inner hole | 3.5 mm | `DEFAULT_INNER_HOLE_SIZE` |
| Base depth | 4 mm | — |
| Text raise | 2 mm | — |

Nudge X/Y default from `DEFAULT_HOLE_NUDGE_X` / `DEFAULT_HOLE_NUDGE_Y` but their
sliders remain visible and adjustable.

Also: symbols removed from the UI but `buildTag` still honours
`symbol.position`; tag width clamped to 50–70mm in both the input attributes and
the handler; millimetres only.

## Viewport

**Centring.** `buildMeshes` measures the combined base+text `Box3` and offsets
the group so its centre is exactly `(0,0,0)` on all three axes. `controls.target`
is always the origin and `enablePan` is off.

**Fit.** `fitDistanceForBox(box, dir, fov, aspect)` is pure and exported. It walks
the eight box corners and solves each against both frustum planes:

    d >= corner·viewDir + |corner·right| / (tan(fov/2) * aspect)
    d >= corner·viewDir + |corner·up|    /  tan(fov/2)

A bounding-sphere fit would also guarantee a fit but over-zooms badly for a wide
flat tag on a short, wide mobile canvas. `test-camera-fit.cjs` projects the
corners through a real `PerspectiveCamera`: 75/75 fit, ~92% frame fill.

**Resize.** `ResizeObserver` calls `setSize(w, h, true)`, updates `camera.aspect`,
`updateProjectionMatrix()`, then re-fits. That third argument **must stay true** —
with `updateStyle=false` the drawing buffer becomes `w*dpr × h*dpr` while no CSS
size is written, so on a 2x phone the canvas lays out at twice its container and
the render spills off the bottom-right.

**Context loss.** `webglcontextlost` otherwise leaves a silently blank canvas, so
it's caught, surfaced in the warning strip, and recovered on restore.

## Mobile notes

- `#preview { height: 31vh; min-height: 170px }`, `auto` at `lg`.
- Preview is `order-1` on phones: a content-sized sidebar placed first in a
  column flex container grows to full height and squeezes the canvas to zero.
- `suppressKeyboard()` blurs any focused text field on capture-phase
  `pointerdown` over a non-text control. The name field is the only control in
  the panel that can raise a keyboard.
- Camera opens top-down under 1024px, iso above.

## Export note

`to3MF` bakes each mesh into the *group's* space, not world space — the group
hangs off a wrapper tilted for the on-screen bed view, and that tilt must not
leak into the exported model.
