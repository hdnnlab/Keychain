# Backpack Tag Generator

Type a name, get a laser-ready SVG, a printable STL, or a two-material 3MF.

## Run the source

    npm install
    npm run build          # writes app.css + app.js next to index.html

Then serve the folder (`npx serve .`) and open `index.html`.

## Layout

| File | What it does |
| --- | --- |
| `src/core.js` | All geometry. opentype outlines → flatten → Clipper union/offset/boolean → THREE meshes → SVG / STL / 3MF. No DOM access. |
| `src/app.js` | Controls, viewport, export wiring. |
| `src/fonts.js` | Nine OFL fonts, Latin-subset and base64-inlined so the tool works offline. |
| `tw.css` | Base layer (slider skin, preview sizing) plus the component classes. |
| `index.html` | Markup only; every class comes from the Tailwind build. |

## Mobile notes

- **Preview height** lives in `tw.css` as `#preview { height: 31vh }`, down 40%
  from the previous 52vh, with `min-height: 170px` so it can't collapse to a
  sliver once the toolbar and stats strip take their share. `auto` at `lg`.
- **Source order** matters: the preview is `order-1` on phones. A content-sized
  sidebar placed first in a column flex container grows to its full height and
  squeezes the canvas to zero.
- **Keyboard suppression** is `suppressKeyboard()` in `app.js`. A capture-phase
  `pointerdown` listener blurs any focused text field the moment a non-text
  control is touched, and releases focus from a range when the gesture ends.
  The hanger diameters are sliders rather than number inputs, so the only
  control that can raise a keyboard at all is the name field.
- **Camera** opens top-down under 1024px, iso above it. It re-frames on
  `orientationchange`, and on resize only when the breakpoint is actually
  crossed — re-framing on every resize would yank the camera away from
  wherever the user had rotated it.

## Fixed / hidden by request

- Base depth 4mm and text raise 2mm: inputs remain in the DOM (the solver reads
  them) inside a `hidden` wrapper. Remove that class to expose them.
- Symbols: UI removed, but `core.js` keeps the full library and `buildTag` still
  honours `symbol.position`. `app.js` passes `"none"`.
- Tag width is clamped to 50–70mm in both the input attributes and the handler.
- Units are millimetres only; the mm/inch toggle is gone.

## Pipeline

    text ──opentype──▶ outlines ──flatten──▶ polygons ──union──▶ weld
                                                                  │
                                        offset +outline ──▶ base plate contour
                                                                  │
                                  hanger ring union ──▶ bridge islands
                                                                  ▼
                                                      subtract inner hole
                                                                  │
                          ┌───────────────────────────────────────┼───────────┐
                          ▼                       ▼                           ▼
                     SVG (2 layers)        extrude → STL             extrude → 3MF

Bridging runs *after* the ring is welded on and *before* the hole is drilled: a
corner-mounted ring can land where the plate's rounded contour doesn't reach,
and drilling last stops a bridge being routed through the keyring hole.
