# Backpack Tag Generator

Type a name, get a laser-ready SVG, a printable STL, or a two-material 3MF.

    npm install
    npm run build            # writes app.css + app.js next to index.html
    npm run test:camera      # camera fit against a real frustum
    npm run test:download    # mobile save paths, incl. a simulated iPhone
    npm run test:size        # width range and the 30mm height cap

## Layout

| File | What it does |
| --- | --- |
| `src/core.js` | All geometry. opentype outlines → flatten → Clipper union/offset/boolean → THREE meshes → SVG / STL / 3MF. No DOM access. |
| `src/app.js` | Controls, viewport, camera fit, export wiring. |
| `src/fonts.js` | 23 Google Fonts families, subset and inlined. See `FONTS.md`. |
| `tw.css` | Base layer (slider skin, preview and canvas sizing) plus component classes. |
| `fonts-licenses/` | OFL / Apache notices. Keep on redistribution. |
| `fonts-src/` | The subset TTFs, for `test:size` and for regenerating `fonts.js`. |

## What the user can change

Text, font (or upload one), tag width, outline size, hanger on/off, hanger
position, hanger nudge X/Y, keep-in-one-piece, and the two colours. Everything
else is fixed.

## Colours

`PALETTE` in `app.js` is the single source of truth — eight fixed colours, no
freeform picker anywhere:

| | | |
| --- | --- | --- |
| Purple `#8A2BE2` *(background default)* | White `#FFFFFF` *(text default)* | Gray `#A9A9A9` |
| Black `#000000` | Pink `#FF69B4` | Dark Blue `#00008B` |
| Red `#FF0000` | Red Brown `#8B3A3A` | |

`buildSwatches()` renders both grids from that array, so adding or removing a
colour is a one-line edit. Selection is exclusive, the active swatch takes a lime
ring, and each button carries `role="radio"` with `aria-checked` and a name label
— White and Black are otherwise indistinguishable to a screen reader.

Colours are preview-only for STL (a mesh has no colour) but do carry into the SVG
fills and the two 3MF `basematerials`, so an AMS or MMU separates plate from
lettering.

## Fixed values (controls hidden, solver still fed)

Each input stays in the DOM inside a `hidden` wrapper so its handler still binds
and the solver still reads it. Delete the `hidden` class to bring the control
back — no JS change needed.

| Control | Value | Constant |
| --- | --- | --- |
| Connect text | on, but inert at gap 0 | — (`.toggle-row.hidden`) |
| Weld gap | 0% | — (`#wrap-gap`) |
| Outer ring | 8 mm | `DEFAULT_OUTER_RING_SIZE` |
| Inner hole | 3.5 mm | `DEFAULT_INNER_HOLE_SIZE` |
| Base depth | 4 mm | — |
| Text raise | 2 mm | — |

Connect text and the weld gap are a pair: `weld()` returns its input unchanged at
gap 0, so the toggle does nothing on its own. Un-hide **both** to restore
welding. Symbols are removed from the UI but `buildTag` still honours
`symbol.position`. Millimetres only.

## Defaults

Text "Calla", font Spicy Rice, background Purple, text White, outline 17%, tag
width 55mm, base depth 4mm, text raise 2mm, hanger top-left with an 8mm ring, a
3.5mm hole and a nudge of (+4.5, −0.5) mm.

## Size limits

Width: 50–60mm, default 55, clamped in the slider attributes and the handler.

Height is **not** an input — it falls out of the lettering's proportions. The
30mm cap (`MAX_TAG_HEIGHT`) is enforced by re-solving: `buildTag` solves at the
width-derived scale, measures the finished height, and re-solves at
`scale * (30 / height)` if it overshoots, up to five passes. It iterates rather
than scaling the finished paths because the keyring is an absolute 8mm/3.5mm and
must not shrink with the text.

A short name hits the cap before reaching the requested width — "Jo" at 55mm
would be 46mm tall, so it returns 34 × 30. A "capped to 30 mm tall" chip appears
beside the slider when that happens.

## Saving files on a phone

`saveFile()` works around three traps — change it carefully:

1. **iOS.** `<a download>` is unreliable in Safari, especially from a `file://`
   page or an in-app browser, so the Web Share sheet is tried first there.
2. **Anchor lifetime.** Removing the anchor or revoking its object URL in the
   same tick as `.click()` cancels the download on several mobile browsers.
3. **MIME type.** `model/stl` makes some browsers navigate to a preview instead
   of saving, so everything goes out as `application/octet-stream`.

Exports must not `await` anything slow before reaching `saveFile` or the tap's
transient activation is spent. 3MF zips asynchronously and may need a second tap.
Every export reports through `showNote()` — a failure is never silent.

## Viewport

**Centring.** `buildMeshes` measures the combined base+text `Box3` and offsets
the group so its centre is exactly `(0,0,0)` on all three axes.

**Fit.** `fitDistanceForBox(box, dir, fov, aspect)` is pure and exported: it
walks the eight box corners and solves each against both frustum planes. A
bounding-sphere fit would also work but over-zooms badly for a wide flat tag on a
short mobile canvas. Tested 75/75 fit, ~92% frame fill.

**Resize.** `setSize(w, h, true)` — that third argument **must stay true**. With
`updateStyle=false` the drawing buffer becomes `w*dpr × h*dpr` while no CSS size
is written, so on a 2x phone the canvas lays out at twice its container and the
render spills off the bottom-right.

**Context loss.** `webglcontextlost` otherwise leaves a silently blank canvas.

## Mobile notes

- `#preview { height: 31vh; min-height: 170px }`, `auto` at `lg`.
- Preview is `order-1` on phones: a content-sized sidebar placed first in a
  column flex container grows to full height and squeezes the canvas to zero.
- `suppressKeyboard()` blurs any focused text field on capture-phase
  `pointerdown` over a non-text control.
- Camera opens top-down under 1024px, iso above.

## Export note

`to3MF` bakes each mesh into the *group's* space, not world space — the group
hangs off a wrapper tilted for the on-screen bed view, and that tilt must not
leak into the exported model.
