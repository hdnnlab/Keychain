// Exercise the iOS path and the failure path, which the desktop run never hits.
const { JSDOM } = require('jsdom'); const fs = require('fs');
function boot(ua, platform, touchPoints, shareImpl) {
  delete require.cache[require.resolve('./apptest.cjs')];
  const dom = new JSDOM(fs.readFileSync('index.html','utf8').replace(/<script[\s\S]*?<\/script>/g,''), { pretendToBeVisual:true, url:'http://localhost/' });
  const w = dom.window;
  ['window','document','HTMLElement','Option','Blob','File','FileReader','Image','Event'].forEach(k=>{ if(w[k]!==undefined) global[k]=w[k]; });
  global.ResizeObserver = class { observe(){} disconnect(){} };
  global.requestAnimationFrame = fn => setTimeout(fn,0);
  w.matchMedia = q => ({ matches:/max-width:\s*1023px/.test(q), addEventListener(){}, removeEventListener(){}, addListener(){}, removeListener(){} });
  global.matchMedia = w.matchMedia; global.self = global.window = w;
  global.URL.createObjectURL=()=>'blob:x'; global.URL.revokeObjectURL=()=>{};
  global.PointerEvent = w.PointerEvent || w.Event;
  // Node 22 exposes globalThis.navigator via a getter, so a plain assignment is
  // silently dropped and the app would read Node's navigator instead of ours.
  const nav = { userAgent: ua, platform, maxTouchPoints: touchPoints, ...shareImpl };
  Object.defineProperty(globalThis, 'navigator', { value: nav, configurable: true, writable: true });
  Object.defineProperty(w, 'navigator', { value: nav, configurable: true });
  global.File = w.File;
  require('./apptest.cjs');
  return w;
}

const IOS_UA = 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_5 like Mac OS X) AppleWebKit/605.1.15 Safari/604.1';

(async () => {
  // --- 1. iPhone with Web Share for files: must use the share sheet, not an anchor
  let shared = null, anchorUsed = false;
  let w = boot(IOS_UA, 'iPhone', 5, {
    canShare: (d) => !!(d && d.files && d.files.length),
    share: async (d) => { shared = d.files[0].name + ' (' + d.files[0].type + ')'; },
  });
  const orig = w.document.createElement.bind(w.document);
  w.document.createElement = (t) => { const el = orig(t); if (t==='a') el.click = () => { anchorUsed = true; }; return el; };
  await new Promise(r => setTimeout(r, 900));
  w.document.getElementById('btn-stl').click();
  await new Promise(r => setTimeout(r, 900));
  console.log('iPhone + Web Share -> shared:', shared, '| fell back to anchor:', anchorUsed);
  console.log('  feedback:', JSON.stringify(w.document.getElementById('warn').textContent.slice(0,55)));

  // --- 2. iPhone WITHOUT file sharing (older iOS / in-app browser): anchor fallback
  let anchor2 = null;
  w = boot(IOS_UA, 'iPhone', 5, { canShare: () => false });
  const orig2 = w.document.createElement.bind(w.document);
  w.document.createElement = (t) => { const el = orig2(t); if (t==='a') el.click = () => { anchor2 = el.download; }; return el; };
  await new Promise(r => setTimeout(r, 900));
  w.document.getElementById('btn-stl').click();
  await new Promise(r => setTimeout(r, 900));
  console.log('iPhone, no file share -> anchor download:', anchor2);

  // --- 3. user dismisses the share sheet: must not look like an error
  w = boot(IOS_UA, 'iPhone', 5, {
    canShare: () => true,
    share: async () => { const e = new Error('cancel'); e.name = 'AbortError'; throw e; },
  });
  await new Promise(r => setTimeout(r, 900));
  w.document.getElementById('btn-stl').click();
  await new Promise(r => setTimeout(r, 900));
  console.log('share sheet dismissed -> message:', JSON.stringify(w.document.getElementById('warn').textContent.slice(0,40)));

  // --- 4. export throws: the user must be told, and the button must recover
  w = boot('Mozilla/5.0 (Linux; Android 14) Chrome/120', 'Linux armv8l', 5, {});
  await new Promise(r => setTimeout(r, 900));
  const btn = w.document.getElementById('btn-stl');
  global.URL.createObjectURL = () => { throw new Error('quota exceeded'); };
  btn.click();
  await new Promise(r => setTimeout(r, 900));
  console.log('export failure -> message:', JSON.stringify(w.document.getElementById('warn').textContent.slice(0,45)),
              '| button re-enabled:', !btn.disabled);
})();
